package com.skinner.DataLayer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class MyFileIO {
    public boolean saveFileBuff(String sFileName, String sMessage){
        boolean bReturn = true;

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(sFileName));
            writer.write(sMessage);
            writer.close();
        }catch (Exception e){
            //todo add something

            bReturn = false;
        }
        return bReturn;
    }

    public String readTextFile(String sFileName){
        StringBuilder sbReturn = new StringBuilder();

        try {
            File myfile = new File(sFileName);
            Scanner myReader = new Scanner(myfile);

            while (myReader.hasNextLine()){
                sbReturn.append(myReader.nextLine());
                sbReturn.append("\n");
            }
            myReader.close();

        }catch (Exception e){
            //todo add something
        }

        return sbReturn.toString();
    }

    public boolean SaveFileStream(String sFileName, String sMessage){
        boolean bReturn = true;

        try {
            FileOutputStream oStream = new FileOutputStream(sFileName);
            byte[] strToByte = sMessage.getBytes();
            oStream.write(strToByte);
            oStream.close();
        }catch (Exception e){
            //todo add something

            bReturn = false;
        }
        return bReturn;
    }

    public String[] readTextFileToArray(String sFileName){
        ArrayList<String> out = new ArrayList<>();
        String[] go;
        try {
            File myfile = new File(sFileName);
            Scanner myReader = new Scanner(myfile);

            while (myReader.hasNextLine()){
                out.add(myReader.nextLine());
            }
            myReader.close();

        }catch (Exception e){
            //todo add something
        }
        go = new String[out.size()];
        for (int i = 0; i < out.size(); i++) {
            go[i] = out.get(i);
        }

        return go;
    }

}
