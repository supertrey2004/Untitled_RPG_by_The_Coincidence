package com.skinner;

import com.skinner.Controller.TopController;

public class Main {
    public static void main(String[] args){
        TopController controller = new TopController();
        controller.Start();
    }
}