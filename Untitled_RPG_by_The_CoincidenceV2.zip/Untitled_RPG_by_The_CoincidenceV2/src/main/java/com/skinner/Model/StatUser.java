package com.skinner.Model;

public abstract class StatUser {

    protected Stat hp = new Stat("HP", 1);
    protected Stat atk = new Stat("Attack", 0);
    protected Stat mag = new Stat("Magic", 0);
    protected Stat agi = new Stat("Agility", 0);
    protected Stat cha = new Stat("Charisma", 0);

    public abstract void setHp(int hp);
    public abstract void setAtk(int atk);

    public abstract void setMag(int mag);

    public abstract void setAgi(int agi);

    public abstract void setCha(int cha);

    public Stat getHp() {
        return hp;
    }
    public Stat getAtk() {
        return atk;
    }
    public Stat getMag() {
        return mag;
    }
    public Stat getAgi() {
        return agi;
    }
    public Stat getCha() {
        return cha;
    }


    private boolean player = false;

    public boolean isPlayer() {
        return player;
    }

    public void setPlayer(boolean player) {
        this.player = player;
    }

}
