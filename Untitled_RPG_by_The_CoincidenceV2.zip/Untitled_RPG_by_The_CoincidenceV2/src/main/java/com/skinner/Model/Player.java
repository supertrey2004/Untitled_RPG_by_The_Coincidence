package com.skinner.Model;

public class Player extends StatUser {
    private final short max = 60;
    private final short min = -5;

    public String name;

    public Player(String name) {
        this.name = name;
    }

    public Player(String name, int hp, int atk, int mag, int agi, int cha){
        this.name = name;
        setHp(hp);
        setAtk(atk);
        setMag(mag);
        setAgi(agi);
        setCha(cha);
        setPlayer(true);
    }

    public void incStats(int stats, Stat stat){
        if(stat == hp)
            super.hp.value += stats;
        else if(stat == atk)
            super.atk.value += stats;
        else if(stat == mag)
            super.mag.value += stats;
        else if(stat == agi)
            super.agi.value += stats;
        else if(stat == cha)
            super.cha.value += stats;
    }

    @Override
    public void setHp(int hp) {
        if (hp >= 0 && hp <= max)
            this.hp.value = hp;
        else if(hp > max)
            this.hp.value = max;
        else
            this.hp.value = 0;
    }

    @Override
    public void setAtk(int atk) {
        if (atk >= min && atk <= max)
            this.atk.value = atk;
        else if(atk > max)
            this.atk.value = max;
        else
            this.atk.value = min;
    }

    @Override
    public void setMag(int mag) {
        if (mag >= min && mag <= max)
            this.mag.value = mag;
        else if(mag > max)
            this.mag.value = max;
        else
            this.mag.value = min;
    }

    @Override
    public void setAgi(int agi) {
        if (agi >= min && agi <= max)
            this.agi.value = agi;
        else if(agi > max)
            this.agi.value = max;
        else
            this.agi.value = min;
    }

    @Override
    public void setCha(int cha) {
        if (cha >= min && cha <= max)
            this.cha.value = cha;
        else if(cha > max)
            this.cha.value = max;
        else
            this.cha.value = min;
    }

    public short getMax() {
        return max;
    }
}