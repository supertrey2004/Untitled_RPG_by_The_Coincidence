package com.skinner.Model;

public class Enemy extends StatUser {
    public String title;

    private int health;

    public Enemy(String title, int hp, int atk, int mag, int agi, int cha){
        this.title = title;
        setHp(hp);
        setAtk(atk);
        setMag(mag);
        setAgi(agi);
        setCha(cha);
        health = hp * 10;
        setPlayer(false);
    }

    public void setHealth(int health) {
        int temp = this.health;
        temp += health;
        this.health = temp;
    }

    @Override
    public void setHp(int hp) {
        this.hp.value = hp;
    }

    @Override
    public void setAtk(int atk) {
        this.atk.value = atk;
    }

    @Override
    public void setMag(int mag) {
        this.mag.value = mag;
    }

    @Override
    public void setAgi(int agi) {
        this.agi.value = agi;
    }

    @Override
    public void setCha(int cha) {
        this.cha.value = cha;
    }


    public int getHealth() {
        return health;
    }

    @Override
    public String toString() {
        return "Name: " + title + ", HP: ";
    }
}