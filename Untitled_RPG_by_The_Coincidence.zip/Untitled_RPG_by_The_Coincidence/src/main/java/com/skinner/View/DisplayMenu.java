package com.skinner.View;

import com.skinner.Model.Events;
import com.skinner.Model.Player;

public class DisplayMenu {

    public void display(String s){
        System.out.println(s);
    }

    public int startMenu(){
        Console.writeLn("Welcome to the Untitled RPG!\n\nWhat do you want to do?");
        return Console.getIntInput("(1) New Game \n(2) Load Save",1,2);
    }

    public int battle(String state){
        Console.writeLn(state, Console.TextColor.RED);
        return Console.getIntInput("(1) Attack \n(2) Heal \n(3) Run",1,3);
    }

    public String strReturn(String text){
        return Console.getStringInput(text,false);
    }

    public int StatChanger(int num){
        Console.writeLn("You have " + num + " Stat Points left");
        return Console.getIntInput("(1) Health \n(2) Attack \n(3) Magic \n(4) Agility \n(5) Charisma",1,5);
    }

    public void showEvent(Events event){
        Console.writeLn(event.getTitle());
        Console.writeLn(event.getDesc());
    }

    public int showChoice(Events[] events){
        String out = "";
        for (int i = 0; i < events.length; i++) {
            out += "\n("+ (i+1) +") "+ events[i].getTitle();
        }
        return Console.getIntInput(out,1,events.length);
    }

    public void playerStats(Player player){
        Console.writeLn("");
        Console.writeLn(player.name);
        Console.writeLn("Health: " + player.getHp().value, Console.TextColor.GREEN);
        Console.writeLn("Attack: " + player.getAtk().value, Console.TextColor.RED);
        Console.writeLn("Magic: " + player.getMag().value, Console.TextColor.BLUE);
        Console.writeLn("Agility: " + player.getAgi().value, Console.TextColor.YELLOW);
        Console.writeLn("Charisma: " + player.getCha().value, Console.TextColor.PURPLE);
        Console.getStringInput("Press Enter to continue",true);
    }
}