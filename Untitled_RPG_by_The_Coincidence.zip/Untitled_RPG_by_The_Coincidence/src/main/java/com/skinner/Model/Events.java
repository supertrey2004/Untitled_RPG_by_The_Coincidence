package com.skinner.Model;

public class Events {
    private String Title;
    private String desc;
    private int type;
    private Events[] subEvents;
    private Enemy[] enemy;
    private boolean hasChoices;
    private boolean isBattle = false;
    //-----------------------------------------------------------

    public Events(String title, String desc, int type, Events[] subEvents, Enemy[] enemy, boolean hasChooses) {
        Title = title;
        this.desc = desc;
        this.type = type;
        this.subEvents = subEvents;
        this.enemy = enemy;
        this.hasChoices = hasChooses;

        if (enemy != null){
            this.isBattle = true;
        }
    }

    //-----------------------------------------------------------
    public String getTitle() {
        return Title;
    }
    //-----------------------------------------------------------

    public String getDesc() {
        return desc;
    }
    //-----------------------------------------------------------
    public int getType() {
        return type;
    }
    //-----------------------------------------------------------

    public Events[] getSubEvents() {
        return subEvents;
    }

    public Enemy[] getEnemy() {
        return enemy;
    }

    public boolean hasChoices() {
        return hasChoices;
    }

    public boolean isBattle() {
        return isBattle;
    }
}
