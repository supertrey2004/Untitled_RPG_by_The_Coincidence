package com.skinner.Model;

public class Stat {
    public String title;
    public int value;

    public Stat(String title, int value){
        this.title = title;
        this.value = value;
    }
}