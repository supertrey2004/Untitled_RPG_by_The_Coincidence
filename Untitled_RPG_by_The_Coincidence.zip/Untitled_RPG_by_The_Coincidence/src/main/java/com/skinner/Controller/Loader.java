package com.skinner.Controller;

import com.skinner.Model.Enemy;
import com.skinner.Model.Events;
import java.util.ArrayList;

public class Loader {
// //////////////////////////// time
     /*
        set.add(mainSet("boom","die", null, new Enemy[]{new Enemy("Creeper",5,20,-5,20,-5)},false));
        list.add(mainSet("test","testing",new Events[]{set.get(0), set.get(1)},null, false));

        list.add(randomSet("Year 7","Something random will happen this year.",null,null,false));
     */



    public Events[] timeline1(){
        ArrayList<Events> list = new ArrayList<>();
        ArrayList<Events> set = new ArrayList<>();
        // 0)/////////////////////////////////////////////
        list.add(mainSet("Year 1", "As you start your journey into the vast world you start as a little baby. \n" +
                "There isn't much to do right now as you can't even walk much less fight.\n" +
                "So well Skip Forward a little\n", null, null, false));
        // 1)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Fight", "After successfully fighting the snake you notice how much stronger you've grown \n" +
                "+2 HP\n" + "+1 ATK\n", null, null, false));
        set.add(mainSet("Run", "After running from the snake your parents end up scaring it away and you continue on with life ",null,null,false));
        list.add(mainSet("Year 5", "As you lived your life and grew up your parents now expect you to help out in the fields and also to help with the animals.\n" +
                "One day as you are helping feed the cattle you notice something green speeding towards you.\n" + "IT'S A SNAKE \n", new Events[]{set.get(0), set.get(1)}, null, true));
        // 2)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Grab Book", "As the glow drags you towards the book you open it and find it to be filled with ancient texts that you can't read.\n" +
                "So you decide to put the book back as the glow fades.\n", null, null, false));
        set.add(mainSet("Ask Father", "After asking your Father about the book he slowly teaches you both how to read books \n" +
                "and how to understand the ancient language that is used for magic. You Gain a Basic Understanding of Magic!\n" +
                "+1 to Magic\n",null,null,false));
        list.add(mainSet("Year 6", "After wandering into your fathers Study you notice a book with a faint yellow glow, the glow reminds you of the summer sun and also campfires.\n" +
                "After much debate you decide to \n", new Events[]{set.get(2), set.get(3)}, null, true));
        // 3)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 7","Something random will happen this year.",2,null));
        // 4)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Offer Help", "The young woman thanks you many times as you help carry the baskets filled with baked goods to her stall at the market. \n" +
                "She decides to give you some pastries as a thank you!\n" +
                "+1 charisma \nOnce arriving at the library you notice that there are plenty of books that you can study to learn more about the world!\n" +
                "You spend the rest of the day at the library and after a long day of studying you head back home \n" +
                "+1 Magic\n", null, null, false));
        set.add(mainSet("Walk By", "After walking by the young woman many people look towards you and wonder why you didn't offer to help the woman.\n" +
                "After all of the strange looks you decide to head home instead of to the library.(You should've helped her)\n" +
                "-1 charisma \n",null,null,false));
        list.add(mainSet("Year 8", "After your strange encounter in your fathers study years ago you decide to try and read more books and gain an understanding of the world around you\n" +
                "as you are headed to the library you notice a young woman struggling to carry some baskets will you?\n", new Events[]{set.get(4), set.get(5)}, null, true));
        // 5)------------------------------------------------------------------------------------------------------------------------
        list.add(mainSet("Year 10", "While spending time helping your family on the farm you notice that you have grown considerably stronger than before \n" +
                "+2 strength\n", null, null, false));
        // 6)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Step In", "You make a dramatic entrance (the best you can for being 11) and after the bullies recover from shock they start yelling at you to back away \n" +
                "accusing this little girl of stealing from them. You manage to talk the down and make them believe that she didn't steal anything \n" +
                "+1 charisma \n", null, null, false));
        set.add(mainSet("Ignore them", "After seeing what the yelling was about you decide that it wasn't worth your time and you go back to your work on the farm and \n" +
                "wonder what would happen if you stepped in\n" +
                "-1 to charisma \n",null,null,false));
        list.add(mainSet("Year 11", "While helping your parents on your farm one day you hear shouts near your farm so you move close to investigate.\n" +
                "You see a group of boys bullying a small girl. Do you \n", new Events[]{set.get(6), set.get(7)}, null, true));
        // 7)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 12", "something random was foretold for this year ",2,null));
        // 8)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Drink", "(WHY WOULD YOU DRINK SOMETHING YOU FOUND IN A FOREST HUT)\n" +
                "After drinking the weird object you get very ill (-250 to ALL STATS)\n", null, null, false));
        set.add(mainSet("Dont Drink", "Literally nothing happens \uD83D\uDC4D",null,null,false));
        list.add(mainSet("Year 13", "While wandering around the forest you encounter a hut that has a weird looking bright red cup can with brown fizzy liquid inside, the outside says Co-- --la with faded letters \n", new Events[]{set.get(8), set.get(9)}, null, true));
        // 9)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Go With Him", "+3 magic +1 str +1 charisma \n" +
                "After arriving and studying at Hogwarts you realize that all the wizards are huge nerds who can't think outside of the box.\n" +
                "After testing a new combination of words to create spells you end up destroying half of the school in the process getting you kicked out.\n", null, null, false));
        set.add(mainSet("Stay Home", "You decide to stay at home and work on the farm to help your parents and you also continue to go to the library to study the world around you \n" +
                "+3 strength +2 agility +1 magic +3 hp\n",null,null,false));
        list.add(mainSet("Year 14",
                "After the weird hut encounter last year life has progressed normally until a very large man with a funny accent knocks on your door. \n" +
                "He is easily 8ft tall with a bright pink object hanging from his hip. He was sent here to direct you to a school of magic called Hogwarts. Will You\n" +
                "(Go with him) or (Stay at home)\n", new Events[]{set.get(10), set.get(11)}, null, true));
        // 10)------------------------------------------------------------------------------------------------------------------------
        list.add(mainSet("Year 17", "You leave home and go out to explore the world.\n", null, null, false));
        // 11)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Protect the man", "Fight the bandit\n", null,new Enemy[]{new Enemy("bandit",2,2,0,3,0)}, false));
        set.add(mainSet("Take a different Route", "After taking a different route, you find a hidden village in the distance!\n",null,null,false));
        list.add(mainSet("Year 18", "After wandering the world for a year you have hopped from town to town and tried to experience life to its fullest \n" +
                "while traveling to a new town you encounter a bandit trying to rob a young man. Do you\n" +
                "(Protect the man) or (Take a different route)\n", new Events[]{set.get(12), set.get(13)}, null, true));
        // 12)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 19","While making your way to the village something unexpected will happen",2,null));
        // 13)------------------------------------------------------------------------------------------------------------------------
        list.add(mainSet("Year 20", "During your travels, you stumble upon a hidden village in the mountains. \n" +
                "The villagers, intrigued by your presence, invite you to participate in their annual festival, where they celebrate the harmony between nature and magic. \n" +
                "You learn traditional dances, partake in magical ceremonies, and make new friends.\n" +
                "+2 Magic\n" +
                "+2 strength \n", null, null, false));
        // 14)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Observe Puddle", "The moment you stop and take a look, a very shiny sword rises out of the puddle (like the lady of the lake) \n" +
                "The sword presents itself to you \n" +
                "+8 strength \n", null, null, false));
        set.add(mainSet("Talk a wide path around the puddle ", "Deciding not to risk the unknown, you watch the pond from afar. \n" +
                "While you don't gain any immediate benefits, you continue your journey with caution.\n",null,null,false));
        list.add(mainSet("Year 21", "As you continue your journey, you come across a dirty puddle deep in the heart of a magical forest. \n" +
                "The water appears to have unique properties, offering those who \n", new Events[]{set.get(14), set.get(15)}, null, true));
        // 15)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 22","Something random will happen to prepare you",2,null));
        // 16)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 23","Something random will happen to prepare you",2,null));
        // 17)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 24","Something random will happen to prepare you for next year",2,null));
        // 18)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Leave it alone", "(\uD83D\uDE10 \uD83D\uDE2Bwhy'd you skip the story)\n" +
                "You decide to not explore the noise and continue on your journey. Always wondering what would've happened if you explored the cave.\n", null, null, false));
        /* 25.3*/set.add(mainSet("Follow the Golem", "Once you start following the golem the air around you seems to be teeming with magical energy and also heat. " +
                "After following the golem for quite a while you notice the area has opened up alot and the huge cavern with many pools of lava and many Many more golems all making the same sort of rumbling noise that the first golem was making when you encountered it.\n +" +
                "After seeing the many golems wandering around in the cavern you decide to try and get a closer look at what is happening. \n" +
                "As you Approach you see the corpse of a dead golem as you move closer you see the exposed core of the golem and decide to touch it\n" +
                "After touching the core all of the golems turn and look at you! Unfortunately (or Fortunately) it notices you and you are forced to take action\\n",null,null,false));
        /* 25.2*/set.add(mainSet("Continue on", "After deciding to investigate the noise further you notice a huge boulder. But the boulder is moving? How can that happen?\n " +
                "And then right before your eyes it seems to grow and grow until It gets so big its head is scraping against the cave ceiling and that's when it starts. \n" +
                "The very deep hum. No, not a hum. A rumbling noise is coming from the golem and is traveling throughout the entire cave system! It suddenly stumbles down another path. Do you\n",new Events[]{set.get(17), set.get(16)}, new Enemy[]{new Enemy("Golem",15,10,10,-3,0),new Enemy("Hat Golem",15,10,10,-3,20),new Enemy("Golem",15,10,10,-3,0)},true));
        /* 25.1*/set.add(mainSet("Go explore the hum", "After agreeing to investigate the noise for the local townspeople you find an abandoned mineshaft in the caves they were talking about.\n" +
                "The lack of cobwebs and dust seems like it has been used recently. Very suspiciously you hear a clunking noise further down the tunnel Do you \n",new Events[]{set.get(18), set.get(16)},null,true));
        /* 25*/list.add(mainSet("Year 25", "After exploring more you stumble upon a small village that has a fair share of weird occurrences and they say they hear a low hum in the caves nearby \n" +
                "They offer you a place to stay if you want to help them but they say that the hum has been there for years and it doesn't bother them. Do you \n", new Events[]{set.get(19), set.get(16)}, null, true));
        // 19)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 26", "something haphazard was foretold for this year ",2,null));
        // 20)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 27", "something whimsical was foretold for this year ",2,null));
        // 21)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Back Away", "As you back away from the mysterious merchant you think to yourself that you did the right thing not introducing yourself to him and also try to stay clear from anything else magical that day.\n", null, null, false));
        set.add(mainSet("Talk with the Merchant", "You attempt to shake off the feeling of dread as the merchant approaches you yet again. \n" +
                "This time you stick out your hand to introduce yourself. The mysterious merchant looks at you with piercing eyes and a sly smile. \n" +
                "\"Ah, finally found ya, I have,\" he says in a raspy voice. \"I've got something special just for you, something that'll change your destiny.\" \n" +
                "You suddenly feel something stab your hand and the strength leaves you and yet you feel more powerful than ever." +
                "-5 str\nBUT\n+8 Mag\n\n",null,null,false));
        list.add(mainSet("Year 28", "You encounter a mysterious traveling merchant who approaches you and says " +
                "“I 'ave been searchin' for ya fur a long Long time” As the merchant approaches you, You get a great feeling of foreboding and you take some steps back. Do you \n", new Events[]{set.get(20), set.get(21)}, null, true));
        // 22)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 29", "something erratic was foretold for this year ",2,null));
        // 23)------------------------------------------------------------------------------------------------------------------------
        list.add(mainSet("Year 30", "You find a nice little town and decide to settle in it after your many years of travels. " +
                "You begin to wonder what happened to your parents during the years you've been away. For now at least you decide to settle down in this nice town.\n",null,null,false));
        // 24)------------------------------------------------------------------------------------------------------------------------
        list.add(mainSet("Year 34", "After a couple years in the town you decide its time to open up a tavern\n" +
                "And since then many people have flocked in to hear the stories of your amazing travels!\n" +
                "Business has been going smoothly for you and nothing weird has happened in a long time.\n",null,null,false));
        // 25)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Reason with Ent", "After approaching the Ent it seems to have become wary of your presence and asks you in rough English " +
                "“What you want? You cut down homes!” as you reason with the Ent explaining why you were cutting down the forest you notice trees behind it seem to be moving like they're trying to " +
                "hear your words. You manage to reason with the Ent and also convince the village to expand in a different direction and also convince the Ent (Ents?) to move further into the " +
                "forest where they won't be disturbed.\n", null, null, false));
        set.add(mainSet("Fight the Ent", "You choose to attack the Ent.\n", null, new Enemy[]{new Enemy("Ent",15,4,20,1,2)}, false));
        list.add(mainSet("Year 35", "With the sudden increase in population the town is forced to expand and while you go help the townspeople gather wood and other supplies to " +
                "build more homes you suddenly hear a shout from one of the men. \n" +
                "You rush over there only to find them being attacked by an Ent!(A living tree) Do you\n",new Events[]{set.get(22), set.get(23)},null,true));
        // 26)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Get Magical Statues", "After getting the statues you realize that you've been scammed because these statues are already breaking down! " +
                "After having them run a couple of shows you decide to throw them away when suddenly you hear a scream and notice one of the statues has a kid's head in their mouth!\n", null, new Enemy[]{new Enemy("Bear Statue",150,0,2,-99,-99)}, false));
        set.add(mainSet("Stay with the normal tavern feel", "You decide that the statues would be too childish for your tavern and decide to skip out on them. " +
                "This turns out ot be a good plan because someone else bought the statues and had an accident where the statues broke shortly after buying and they had an " +
                "incident that's now know as the “The Bite of (14)87”\n", null, null, false));
        list.add(mainSet("Year 36", "After dealing with the Ents your village has become quite peaceful (aside from the few scuffles between drunkin men trying to fist fight them)" +
                "your tavern is thriving with many people coming in and wanting to hear your stories. You think about getting magical moving statues to entertain your guests. " +
                "The statues would be a bear, chicken, bunny and a fox.\n",new Events[]{set.get(24), set.get(25)},null,true));
        // 27)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Live a peaceful life and stop adventuring", "You decide to stay in your town and try to live a peaceful life after your many adventures\n", null, null, false));
        set.add(mainSet("Go out and adventure again", "You decide that your adventuring days are not yet over.\n", null, null, false));
        list.add(mainSet("Year 37", "After spending a couple years in this town you've always wondered what the event they do every year during december but you've never " +
                "asked anyone for fear of being laughed at. One day you decide to ask someone at the tavern and they say “You've never celebrated the Winter Solstice before? I though ye wouldve " +
                "noticed the increase in people during that day. Its an event where we celebrate the moon.” You decide that you're going to join the festival this year and shut down the tavern temporarily(much to many peoples complaints) " +
                "After the celebrations you take a moment and realize how far you've come during your adventures and you debate becoming an adventurer again. Do you\n",new Events[]{set.get(26), set.get(27)},null,true));
        // 28)------------------------------------------------------------------------------------------------------------------------
        list.add(mainSet("Year 38", "You close your tavern to adventure again! But many things have changed in this world and it is now more chaotic and random than before.\n",null,null,false));
        // 29)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 39", "something bizarre was foretold for this year ",2,null));
        // 30)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 40", "something absurd was foretold for this year ",2,null));
        // 31)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 41", "something incoherent was foretold for this year ",2,null));
        // 32)------------------------------------------------------------------------------------------------------------------------
        /* 28right-straight-min*/set.add(mainSet("continue out", "A crowd you didn't realize was there cheers for you as you triumph over the minotaur. You are guided out of the Labyrinth, " +
                "still holding the sword. You are showered with gifts as you go by the crowd.\n" +
                "+5 All Stats\n", null, null,false));
        /* 29right-straight*/set.add(mainSet("go straight", "You come to a large room which looks like a typical cave but there are seats all around the cave as if people " +
                "would come to watch something happen here. Once your eyes adjust you see a weapon rack close to you and you decide to grab a shiny sword (almost as if it was placed here moments ago…) " +
                "you start scanning the cave and see a giant furry object duck its head and rush at you! You manage to dodge it and catch a glimpse of a Minotaur!\n",new Events[]{set.get(28)}, null,true));
        /* 30right-up-right*/set.add(mainSet("go right", "You see some light at the end of the tunnel and rush towards it! You appear to be in the same town that you had just left from " +
                "and the door you ran out was your tavern front door. You enter and exit the door seeing if you'll be forced back into the labyrinth but to no luck. The villagers give you " +
                "confused looks and even you start to doubt if you even left the village or if it was all just a dream. \n" +
                "Perplexed, you leave the village once again and head down a different path this time.\n",null, null,false));
        /* 31right-up-left-leave it*/set.add(mainSet("Leave the room and the Labyrinth", "You decide to not touch the swirling liquid and leave the room " +
                "and struggle to find your way out of the labyrinth as well.\n",null,null,false));
        /* 32right-up-left-touch*/set.add(mainSet("Touch the substance", "You think to yourself and wonder why you wouldn't try and grab the liquid-like object iit could be a really strong weapon for you. " +
                "As the weapon binds to you you get all of the memories of the past users and you feel immensely empowered and you hope you can be a good host for the symbiote\n" +
                "+5str\n" +
                "+3mag\n" +
                "+10hp\n" +
                "+2agil", null,null,false));
        /* 33right-up-left*/set.add(mainSet("go left", "You find yourself in a very bright room with loads of magic crystals on every surface of the room. They seem to be pointing at something. " +
                "As you look towards the back wall you see a swirling liquid-like substance on a pedestal almost like it's calling your name. You're drawn towards the mysterious object, " +
                "moments before you touch it you snap back to reality and wonder if you really should grab something mysterious or not. Do you\n",new Events[]{set.get(32), set.get(31)}, null,true));
        /* 34right-up*/set.add(mainSet("go up", "After walking for what seems like forever you encounter your favorite thing! Yet another crossroads. Do you\n",new Events[]{set.get(33), set.get(30)},null,true));
        /* 35right*/set.add(mainSet("go right", "After going right you see yet another crossroad in the distance (this is a labyrinth after all). Do you\n",new Events[]{set.get(34), set.get(29)},null,true));
        /* 36left-straight-end*/set.add(mainSet("continue", "As you continue down the path you start to trust your gut more and more, no longer needing to even think about your choices. " +
                "You see a treasure chest at the end of the hallway with 2 doors. You open the chest and gain a weird glowing, golden string and it suddenly starts showing you a path. " +
                "After following it for a long time there seems to be a light at the end of the tunnel! You escape successfully always wondering what could've happened if you didn't follow the " +
                "string\n",null,null,false));
        /* 37left-straight*/set.add(mainSet("go straight", "After following the walls for a long time and avoiding the very obvious traps along the way you come to a large open room that " +
                "resembles a colosseum and you notice some weapons on the floor in front of you (almost like someone was waiting for you) as your eyes adjust to the room you see a very large " +
                "skeleton of a four legged animal on the other side of the arena.\n",new Events[]{set.get(36)}, new Enemy[]{new Enemy("Lion Skeleton",3,8,4,6,0)},true));
        /* 38left-up*/set.add(mainSet("go up", "You reach a dead end and get tired of the labyrinth, deciding to turn around and leave the way you came.\n", null, null,false));////TODO
        /* 39left*/set.add(mainSet("go left", "You decide to go left at the turn and hear a sudden scraping noise. After searching for the source of the noise you see skeletons! You sneak around them to continue exploring\n" +
                "After going left and wandering for a while you appear at another crossroads.\n" + "Do you\n\n",new Events[]{set.get(37), set.get(38)}, null,true));
        /* 40go in*/set.add(mainSet("Investigate the structure", "You head into the structure and realize its a maze of rooms! Its almost as if its a labyrinth of sorts. " +
                "After walking for a while you come faced at a crossroads. Do you\n",new Events[]{set.get(39), set.get(35)},null,true));
        /* 41leave*/set.add(mainSet("Ignore it", "(\uD83D\uDE10 \uD83D\uDE2Bwhy'd you skip the story)\n" +
                "You decide to skip out on the stone structure and miss yet another adventure.\n", null, null, false));
        /* 42*/list.add(mainSet("Year 42", "You find a strange stone structure in the middle of a field and wonder what could be inside of it. Do you\n", new Events[]{set.get(40), set.get(41)}, null, true));
        // 33)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 43", "Something big is coming soon",2,null));
        // 34)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 44", "Something big is coming soon",2,null));
        // 35)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 45", "Something big is coming soon",2,null));
        // 36)------------------------------------------------------------------------------------------------------------------------
            set.add(mainSet("Press Enter","",null,null,false));
        set.add(mainSet("Run","After escaping successfully from the Hydra you wonder why the world has been so cruel towards you with making you fight all these legendary monsters",null,null,false));
        set.add(mainSet("Fight","YOU FIGHT THE HYDRA",
                new Events[]{set.get(42)},new Enemy[]{new Enemy("Hydra Head",4,5,8,2,0), new Enemy("Hydra Head",4,5,8,2,0), new Enemy("Hydra Head",4,5,8,2,0), new Enemy("Hydra Head",4,5,8,2,0)},true));
        list.add(mainSet("Year 46", "As you stumble from village to village you're shocked by how random the world has become and you try to just find some nice scenery to calm down at. You see a refreshing lake in the distance and decide to head towards it.\n" +
                "Once closer to the lake you see giant animal tracks and wonder what could've caused them. Shortly after you see said “animal” and it turns out to be a Hydra! Thankfully it hasn't noticed you yet.\n" +
                "Do you\n",new Events[]{set.get(43), set.get(44)},null,true));
        // 37)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 47", "Something big is coming this year",2,null));
        // 38)------------------------------------------------------------------------------------------------------------------------
        list.add(eventsSet("Year 48", "Something big is coming this year",2,null));
        // 39)------------------------------------------------------------------------------------------------------------------------
        set.add(mainSet("Prep", "Heeding the old woman's warning you decide to stay in the town and you start training every. Single. Day. deciding that it doesn't matter if the old woman was crazy its better to be safe than sorry.", null, null, false));
        set.add(mainSet("Run Away", "As you run away from the impending attack you think to yourself and wonder if maybe the dragons were behind all the randomness in this world and also the cause of all of your adventure.\n" +
                "A week later news reaches you that the town and all of the towns surrounding it were destroyed due to the dragon's attacks. You feel guilty knowing you could have saved the townspeople. You become a hermit and live away from society so no one recognizes you as the deserter you are.\n" +
                "You got the BAD ENDING", null, null, false));
        list.add(mainSet("Year 49", "While staying in a town you are approached by an older woman as you pass by she grabs your hand with a non-human strength and tells you”Brave one, you must prepare yourself for the future as it is filled with rubble and flames, there is a great danger approaching you must save us” As the woman says these words you get visions of towns in flame and ruin before the vision ends you hear the roar of a dragon.\n" +
                " Do you\n",new Events[]{set.get(45), set.get(46)},null,true));
        // 40)------------------------------------------------------------------------------------------------------------------------
        /* 47END*/set.add(mainSet("END", "Year 51(END)\n" +
                "After defeating all of the dragons the people agree that you have saved them from a cataclysmic event and that you will go down in legends as a hero. " +
                "You're just happy that the world is finally slowing down for you and letting you rest. You think back on your travels and everything that you've done and wonder how all the people you've met are doing. " +
                "Later down the line you decide to write a book about your adventures for people to learn about everything you've done. \n" +
                "GOOD ENDING\n", null,null,false));
        /* 48people-check-red*/set.add(mainSet("Fight the last dragon", "As you go after the Red dragon who is targeting the people trying to evacuate you see why these dragons are so formidable. With their magic powers and how strong their elements are no normal human could ever fight multiple, thankfully you are no mere human. Go save the people!\n"
                ,new Events[]{set.get(47)},new Enemy[]{new Enemy("Red Inferno",50,15,22,11,39)},true));
        /* 49people-check-white*/set.add(mainSet("Fight the next dragon", "Deciding to go after the white dragon you notice its staging around the harbor and not attacking the townspeople. Until you get closer to it and the temperature rapidly drops. " +
                "Once you can see the area it's circling you understand what its capable of. " +
                "The White dragon's “flames” are cold enough to freeze the water and the very ships people are using to escape. Save the Ships!!\n",new Events[]{set.get(48)}, new Enemy[]{new Enemy("Blue Lightning",30,10,8,11,0)},true));
        /* 50people-check-blue*/set.add(mainSet("Fight dragon", "As you go after the blue dragon terrorizing the village you suddenly see lighting shoot out of its mouth! This one has to be stronger than the Green Poison Dragon. " +
                "As you start to approach it you see that it doesn't just shoot lighting but its entire body is filled with it! To save the village you must fight the dragon!\n",new Events[]{set.get(49)}, new Enemy[]{new Enemy("Blue Lightning",50,12,20,9,0)},true));
        /* 51people-check*/set.add(mainSet("Check Dragon Corpse", "After going back to the dragon corpse to check it you see that it has disintegrated! Only leaving the bones behind and a glowing orb (which of course you grab cause why not) " +
                "After touching the glowing orb you gain partial knowledge about the dragons and understand that there are three more dragons you must fight, Blue Lighting, White Frost and Red Inferno. \n",new Events[]{set.get(50)}, null,true));
        /* 52people-cont*/set.add(mainSet("Continue", "After successfully killing the Green Dragon you look around the town and notice that a majority of the buildings have been destroyed but more people survived.\n", new Events[]{set.get(51)}, null, true));
        /* 53People*/set.add(mainSet("People", "You rush towards the people to rescue them from one of the dragons. You come face to face with the Green dragon who gives you a curious look. " +
                "You hear a voice in your head saying “Why do you not run?” because that's not the right choice. " +
                "The dragon opens its mouth and spits out poison at you (-5 health cause you got hit with poison)\n", new Events[]{set.get(52)}, new Enemy[]{new Enemy("Green Poison",48,10,18,15,0)}, true));
        /* 54town-cont*/set.add(mainSet("continue", "After successfully killing the Drakon, the guards turn to you and say that there are still 3 more dragons that you have to defeat. " +
                "You run off to fight the bigger threats. They are Blue Lighting, White Frost and Red Inferno\n", new Events[]{set.get(50)}, null, true));
        /* 55Town*/set.add(mainSet("Town", "After moving into the town you see the king's guards fighting against a smaller drakon and you decide to join them and help fight.\n",new Events[]{set.get(54)},new Enemy[]{new Enemy("Drakon",20,10,6,10,0)},true));
        /* 50*/list.add(mainSet("Year 50", "You wake up to the roar of dragons and the smell of fire. " +
                "You rush out of your house to go help the townspeople but there is also another dragon focusing on destroying the village itself so your forced to choose \n", new Events[]{set.get(53), set.get(55)}, null, true));
        // ////////////////////////////////////////////
        return arrayChanger(list);
    }
    // //////////////////////////// random

    public Events random(){
        ArrayList<Events> list = new ArrayList<>();
        ArrayList<Events> set = new ArrayList<>();
        // 0)//////////////////////////////////////////
        list.add(randomSet("Calydonian B O A R", "You encounter a wild BOAR, It turns out ot be the Legendary Calydonian Boar!. which charges at you", new Enemy[]{new Enemy("Calydonian BOAR",50,50,0,25,50)},null,false));
        // 1)---------------------------------------------
        list.add(randomSet("B O A R", "You encounter a wild BOAR, which charges at you", new Enemy[]{new Enemy("BOAR",3,5,1,3,-2)},null,false));
        // 2)----------------------------
        list.add(randomSet("12 Snakes in a Trench Coat", "You encounter a weird looking man in a trench coat who slithers? towards you ", new Enemy[]{new Enemy("12 Snakes in a Trench Coat",12,2,-99,5,99)},null,false));
        // 3)----------------------------
        list.add(randomSet("Wolf", "While traveling through the woods you stumble across a rabid wolf and it attacks! ", new Enemy[]{new Enemy("Wolf",3,5,-2,5,0)}, null, false));
        // 4)----------------------------
        list.add(randomSet("Bird", "a bird ends up pooping on you. Y'know, in some cultures it's considered good luck.\n", null, null, false));
        // 5)----------------------------
        list.add(randomSet("Witch", "You get turned into a worm and kept in a terrarium for one year (Would you love me if I was a worm?)\n\n", null, null, false));
        // 6)----------------------------
        list.add(randomSet("Mugger", "-5 gold (jokes on him we didnt program gold so use your imagination)\n\n", null, null, false));
        // 7)----------------------------
        list.add(randomSet("Bandit", " A Bandit mugs a mugger and gives you 5 gold(we didnt program in gold so use your imagination)\n\n", null, null, false));
        // 8)----------------------------
        list.add(randomSet("Villager", "You encounter a strange looking village where everything is made of perfect squares. You go to ask a Villager about it but all he/she says is hrrrrrmmmmmm (minecraft villager sound) \n\n", null,null,false));
        // 9)----------------------------
        list.add(randomSet("Slime", "A very square shaped slime jumps out at you", new Enemy[]{new Enemy("Slime",2,1,1,5,1)},null,false));
        // 10)----------------------------
        list.add(randomSet("Spider", "While taking a shortcut through a cave you hear noises on the cave floor behind you. Its a spider!(ew) \n\n", new Enemy[]{new Enemy("Spider",1,3,-2,4,-5)},null,false));
        // 11)----------------------------
        list.add(randomSet("Horse", "You get a Horse\uD83D\uDC34! (You don't know how to ride a horse. Womp Womp)\n\n\n", null,null,false));
        // 12)----------------------------
        list.add(randomSet("Soup", "Soup: Soup \uD83C\uDF72\n\n\n", null, null, false));
        // 13)----------------------------
        set.add(randomSet("Accept", "You take the pot of honey from the bear. \nAll Stats +1", null, null, false));
        set.add(randomSet("Deny", "You have angered the bear. He will now fight you.", new Enemy[]{new Enemy("Bear",6,6,4,1,10)}, null, false));
        list.add(randomSet("Bear", "A bear wearing a red shirt and a green hat offers you a pot of honey.", null,new Events[]{set.get(0), set.get(1)},true));
        // 14)----------------------------
        list.add(randomSet("Meteor", "Skill diff", null, null, false));
        // 15)----------------------------
        list.add(randomSet("Tsunami", "You never learned how to swim", null, null, false));
        // 16)----------------------------
        list.add(randomSet("Meat", "Meat: Yum \uD83C\uDF56\uD83C\uDF56\uD83C\uDF56", null, null, false));
        // 17)----------------------------
        list.add(randomSet("The Random Rock", "You found a random rock on the ground in this quite pretty so you pick it up \n",
                new Enemy[]{new Enemy("Flying Goblins",5,13,5,15,-5),new Enemy("Flying Goblins",5,13,5,15,-5),new Enemy("Flying Goblins",5,13,5,15,-5),new Enemy("Flying Goblins",5,13,5,15,-5),new Enemy("Flying Goblins",5,13,5,15,-5)},null,false));
        // 18)----------------------------
        list.add(randomSet("Absolutely Insane Forg Wizard", "You stumble upon a green frog in a wizard suit, He claims he is the best wizard and challenges you in a wizard duel \n", new Enemy[]{new Enemy("Absolutely Insane Frog Wizard",5,0,99,1,30)},null,false));
        // 19)----------------------------
        list.add(randomSet("Time Traveller", "“YOU DON'T UNDERSTAND THIS IS ALL A GAME ON SOMEONE'S COMPUTER AND YOU'RE NOT REAL!” They suddenly blip out of existence and you try to forget about the crazy encounter. \n\n", null,null,false));
        // 20)----------------------------
        list.add(randomSet("Talking Plant", "\uD83C\uDFB5Feed me\n" +
                "Feed me \n" +
                "Feed me \n" +
                "Feed me all night long \n" +
                "Take a chance, feed me, yeah \n" +
                "You know the kinda eats \n" +
                "The kinda red-hot treats \n" +
                "The kinda sticky, licky, sweets I crave… \n" +
                "The guy sure looks like plant food to me! \n" +
                "The guy sure looks like plant food to me! \n" +
                "The guy sure looks like plant food to me...! \n" +
                "I need blood and he's got more than enough! \n" +
                "I need blood and he's got more than enough! \n" +
                "So Go Git it\uD83C\uDFB5 \n", null,null,false));
        // 21)----------------------------
        list.add(randomSet("Pirates", "You spend a year adventurin' on ye high seas. Yarr!", null, null, false));
        // 22)----------------------------
        list.add(randomSet("Literally Nothing", "You take a year off and find a nice village to relax from your travels in", null,null,false));
        // 23)----------------------------
        list.add(randomSet("Dog", "A dog approaches you and wants pets\n +1 hp\n", null,null,false));
        // 24)----------------------------
        set.add(randomSet("Accept", "You take the cheese from the Jerome. \nAll Stats +1", null, null, false));
        set.add(randomSet("Deny", "You deny the Cheese Wheel and you have hurt the guards honor as a Cheese Knight. He challenges you to a fight", new Enemy[]{new Enemy("Jerome the Cheese Guard",3,3,3,3,40)}, null, false));
        list.add(randomSet("Jerome the Cheese Guard", "A friendly guard offers you a wheel of Cheese", null,new Events[]{set.get(2), set.get(3)},true));
        // 25)----------------------------
        list.add(randomSet("Portuguese Cat", "Does nothing other than the Markiplier sound(“Oooo Kitty. “Meow” ”Ohhh, you're so Portuguese”)", null,null,false));
        // 26)----------------------------
        list.add(randomSet("A Normal Dude", "A normal dude approaches angrily", new Enemy[]{new Enemy("Normal Dude",1,1,1,1,1)},null,false));
        // 27)----------------------------
        list.add(randomSet("Heart Attack", "You have a Heart Attack", null,null,false));
        // 28)----------------------------
        list.add(randomSet("Stub Toe", "You stub your toe. yeeeOOOOUUUCCCHHHH!!!!! (Tom & Jerry scream)", null,null,false));
        // 29)----------------------------
        list.add(randomSet("Fountain of youth", "After stumbling around in a forest you see a quartz fountain and wonder what it could be as you step closer you see that the water is glowing! " +
                "You decide that the water seems safe enough and you take a drink of the glowing water(Id drink glowing water) ", null,null,false));
        // 30)----------------------------
        list.add(randomSet("GOD", "You encounter a divine entity along your travels and suddenly you feel a rush of energy and strength. The entity disappears in a flash of light.", null,null,false));
        // 31)----------------------------
        list.add(randomSet("Wisconsin Man", "A man approaches you and correctly pronounces \033[3m”bAg”\033[0m\n" +
                "Utah woman\n" +
                "A woman approaches you and corrects the Wisconsin man, “bag”.\n", null,null,false));
        // 32)----------------------------
        list.add(randomSet("Golden Apple", "You find a glowing Golden Apple", null,null,false));
        // 33)----------------------------
        list.add(randomSet("Magical Floating Rock", "You encounter a rock with eyes drawn on it and it appears to be following you. You try your best to forget it's there.", null,null,false));
        // 34)----------------------------
        list.add(randomSet("Breaking Bad", "Become alchemist and then get cursed needing to sell magic crystals to have enough money for a grand mage to remove the curse. " +
                "Then get addicted to the money that your making that you end up making a crystal empire and hire someone called Jared Pinkleson and he helps you expand and monopolize the market. " +
                "Unfortunately after years of making your millions and taking risk after risk you eventually die by an assassin sent by your competitors.\n", null, null, false));
        // 35)----------------------------
        list.add(randomSet("Skeleton", "A skeleton with a sword approaches you. (Oh ho Your approaching me?) \n\n", new Enemy[]{new Enemy("Skeleton",5,8,0,3,0)},null,false));
        // 36)----------------------------
        list.add(randomSet("Orcs", "A pair of orcs fall out of the sky.", new Enemy[]{new Enemy("Orc 1",10,7,-5,3,-5), new Enemy("Orc 2", 10, 7, -5, 3, -5)},null,false));
        // 37)----------------------------
        list.add(randomSet("Skeleton Army", "You encounter an army of 4 Skeletons with swords and armor.", new Enemy[]{new Enemy("Sword Skeleton",2,7,0,5,0),new Enemy("Armor Skeleton",7,3,0,1,0),new Enemy("Archer Skeleton",1,5,0,9,0),new Enemy("General Skeleton",9,8,0,1,0)},null,false));
        // 38)----------------------------
        list.add(randomSet("Troll", "You encounter a Troll. It grabs the nearest tree to use as a weapon", new Enemy[]{new Enemy("Troll",10,10,0,-99,0)},null,false));
        // 39)----------------------------
        list.add(randomSet("Pressure Plate", "You stumble onto a pressure plate out in the woods causing a huge magical contraption to blow up the continent (Dr. Doofenshmirtz-style self destruct) ", null,null,false));
        // 40)----------------------------
        list.add(randomSet("T. Rex", "A talking Tyrannosaurus wanders out of the forest and asks you for a slushie (you don't know what a slushie is)You ask how would he drink it with those little arms? This angers the T. Rex, and he attacks you.", new Enemy[]{new Enemy("T. Rex",20,40,0,5,10)},null,false));
        // 41)----------------------------
        list.add(randomSet("Chartreuse potion", "You find a potion on the ground and decide to drink it \n +5 to all stats\n", null,null,false));
        // 42)----------------------------
        list.add(randomSet("Creeper","You are walking through the forest when all suddenly a green and black creature comes running at you.",new Enemy[]{new Enemy("Creeper",10,40,-5,30,-5)},null,false));
        // 43)----------------------------
        list.add(randomSet("Sinkhole","A sinkhole appears and you fall in. You eventually crawl out, but are in bad shape.\n Hp/2 Agi/2\n",null,null,false));
        // 44)----------------------------
        list.add(randomSet("Piano","A piano falls from the sky and lands in front of you. Miraculously, it is unscathed. You decide to play the piano.\n Cha +MAX\n",null,null,false));
        // 45)----------------------------
        list.add(randomSet("Amalgam","You encounter a great amalgamation of monster flesh (gross). It swiftly attacks you with an unholy fury.",new Enemy[]{new Enemy("Amalgam",25,25,5,3,-5)},null,false));
        // 46)----------------------------
        list.add(randomSet("Mickey Mouse","Mickey Mouse copyright the game and it gets shut down.",null,null,false));
        // 47)----------------------------
        set.add(randomSet("Follow", "After following the strange metal man, he eventually leads you to the monster, but is quickly knocked out, leaving you to fight the monster.", new Enemy[]{new Enemy("Skullgirl",50,15,25,10,15)}, null, false));
        set.add(randomSet("Abstain", "You stay within the town, trying to put the bizarre brass man out of your mind.", null, null, false));
        list.add(randomSet("Brass Man","One day, a bizarre, large being made purely of a glossy, yellow metal and dressed in a large beige coat strolls into the town. " +
                "He speaks in a low, gravely voice, and asks you if you have seen signs of a hellish, undead girl dressed as a maid. When you have no answer for him, he sets out again." +
                "\nDo you\n",null,new Events[]{set.get(4), set.get(5)},true));
        // 48)----------------------------
        list.add(randomSet("Pipe bomb","You find a weird cylinder on the ground and pick it up only for it to explode and injure you\n -5  str",null,null,false));
        // 49)----------------------------
        list.add(randomSet("Forest Fire","A tree falls in front of you after being struck by lightning, summoning 3 Fire Elementals. ",new Enemy[]{
                new Enemy("Fire Elemental",30,20,30,10,20),new Enemy("Fire Elemental",30,20,30,10,20),new Enemy("Fire Elemental",30,20,30,10,20)},null,false));
        // 50)----------------------------
        list.add(randomSet("Gravity Falls","You encounter a talking pyramid with a hat and cain. He asks if you want to make a deal before disapearing",null,null,false));
        // ///////////////////////////////////////////////////////////////////////////
        return eventsSet("randEv", "randEv", 2, arrayChanger(list));
    }

    // ////////////////////////////////
    public Events eventsSet(String title, String desc, int type, Events[] subEvents){
        return new Events(title,desc,type,subEvents,null,false);
    }

    public Events randomSet(String title, String desc, Enemy[] enemy, Events[] subEvents, boolean hasChoices){
        return new Events(title,desc,2,subEvents,enemy,hasChoices);
    }

    public Events mainSet(String title, String desc, Events[] subEvents, Enemy[] enemy, boolean hasChoices){
        return new Events(title,desc,1,subEvents,enemy, hasChoices);
    }

    public Events[] arrayChanger(ArrayList<Events> list){
        Events[] send = new Events[list.size()];
        for (int i = 0; i < list.size(); i++) {
            send[i] = list.get(i);
        }
        return send;
    }
}
