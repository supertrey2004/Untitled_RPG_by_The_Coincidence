package com.skinner.Controller;

import com.skinner.Model.Enemy;
import com.skinner.Model.Events;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;

public class Tracker {
    private int age = 0;
    private Events[] timeLine; //this will need to be instantiated with all the things //love taking up a bajillion lines with one thing
    private Events randEv; //used only for subevents
    private Events blank = new Events("","",1,null,null,false);

    public void ageUp() {
        age++;
    }

    public Events eventChooser() {
        // resets age if out of bounds
        if (age > timeLine.length -1){
            age = timeLine.length -1;
        }

        Events cur = timeLine[age];
        Random rand = new Random();
        if (timeLine[age].getType() == 2) {
            int i = rand.nextInt(0, randEv.getSubEvents().length);
            //i = 47;
            cur = randEv.getSubEvents()[i];
        }
        return cur;
    }

    public Events choiceFind(ArrayList<Events> list, boolean choice){
        if(choice)
            return list.get(0);
        else
            return list.get(1);
    }

    public void setTimeLine(Events[] timeLine) {
        this.timeLine = timeLine;
    }

    public void setRandEv(Events randEv) {
        this.randEv = randEv;
    }

    public void setAge(int age) {

        if (age < 0) {
            this.age = 0;
        } else {
            this.age = age;
        }
    }

    public Events randEventFind(int slot){
        return randEv.getSubEvents()[slot];
    }

    public Events mainEventFind(int slot, int subSlot){
        return timeLine[slot].getSubEvents()[subSlot];
    }

    public int getAge() {
        return age;
    }

    public Events getBlank() {
        return blank;
    }

    public boolean timelineEnd(){
        return this.age != (timeLine.length -1);
    }
}