package com.skinner.Controller;

import com.skinner.Model.Enemy;
import com.skinner.Model.Player;
import com.skinner.Model.StatUser;
import com.skinner.View.DisplayMenu;

import java.util.Random;

public class Battler {
    DisplayMenu io = new DisplayMenu();
    Random rand = new Random();
    private Enemy[] enemy;
    private Player player;
    private int playerHP;
    private String enemyState;
    private boolean loop;
    private boolean run;

// Start of system
    public void start(Enemy[] enemyIn, Player player, boolean canRun) {
        this.enemy = new Enemy[enemyIn.length];
        for (int i = 0; i < enemyIn.length; i++) {
            this.enemy[i] = new Enemy(enemyIn[i].title,enemyIn[i].getHp().value,enemyIn[i].getAtk().value,enemyIn[i].getMag().value,enemyIn[i].getAgi().value,enemyIn[i].getCha().value);
        }

        this.run = canRun;
        this.player = player;
        this.player.setPlayer(true);
        this.playerHP = player.getHp().value * 10;
        loop = true;
        takeTurn();
    }

    // runs evey turn
    public void takeTurn(){
        int sel = -1;
        // display enemy
        while (loop) {
            enemyState = "";
            for (Enemy value : enemy) {
                if (value != null) {
                    enemyState += value.toString() + value.getHealth() + "/" + value.getHp().value * 10 + "\n";
                }
            }
            enemyState += "\n" + player.name + ", HP: " + playerHP + "/" + player.getHp().value * 10;
            // get user input
            sel = io.battle(enemyState);
            switch (sel) {
                case 1:
                    // Attack
                    for (int i = 0; i < enemy.length; i++) {
                        if (enemy[i] != null) {
                            battle(player, enemy[i], i);
                        }
                    }
                    break;
                case 2:
                    // Heal
                    if (player.getMag().value >= 10){
                        playerHP += player.getMag().value * 2;
                    }

                    break;
                case 3:
                    // Run
                    if (this.run){
                        if (rand.nextInt(4) == 3) {
                            loop = false;
                            io.display("You run away\n");
                        }else {
                            io.display("You failed to run away\n");
                        }
                    }else {
                        io.display("You can't run away\n");
                    }
                    break;
            }
            // run enemy's turns
            for (int i = 0; i < enemy.length; i++) {
                if (enemy[i] != null) {
                    battle(enemy[i], player, i);
                }
            }
        }
    }

    public void battle(StatUser attack, StatUser defense, int enemy){
        int deAgi = Math.max(defense.getAgi().value, 1);

        int hurt = attack.getAtk().value;
        if (attack.getMag().value >= 15){
            hurt += 5;
        }

        if (attack.getCha().value >= 15 && !attack.isPlayer()){
            if (attack.getMag().value >= 10){
                if (rand.nextInt(2) == 1){
                    this.enemy[enemy].setHealth(attack.getMag().value * 2);
                    hurt = 0;
                }
            }
        }

        if (rand.nextInt(deAgi) <= 11){
            if (defense.isPlayer()){
                playerHP = playerHP - hurt;
            }else {
                this.enemy[enemy].setHealth(-hurt);
            }
        }
        checkUp(defense, enemy);
    }

    public void checkUp(StatUser user, int enemyS){
        if (user.isPlayer()){
            if (playerHP <= 0){
                player.setHp(0);
                loop = false;
            }
        }else {
            if (enemy[enemyS].getHealth() <= 0){
                int ch =0;
                enemy[enemyS] = null;

                for (Enemy value : enemy) {
                    if (value != null) {
                        ch++;
                    }
                }
                if (ch == 0){
                    loop =false;
                    io.display("You Win");
                }
            }
        }

    }
}
