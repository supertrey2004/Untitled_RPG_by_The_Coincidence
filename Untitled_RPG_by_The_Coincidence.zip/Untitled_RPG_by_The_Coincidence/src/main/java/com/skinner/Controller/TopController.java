package com.skinner.Controller;

import com.skinner.DataLayer.MyFileIO;
import com.skinner.Model.Events;
import com.skinner.Model.Player;
import com.skinner.View.DisplayMenu;

import java.util.Random;

public class TopController {
    Battler battle = new Battler();
    Tracker tracker = new Tracker();
    Loader loader = new Loader();
    MyFileIO file = new MyFileIO();
    DisplayMenu io = new DisplayMenu();
    Random rand = new Random();
    Player player;
    Events event;

    boolean god = false;
    int godAge = 0;

    boolean gameOn = true;

    public void Start(){
        tracker.setTimeLine(loader.timeline1());
        tracker.setRandEv(loader.random());

        int sel = -1;
        boolean loop = true;
        while (loop){
            sel = io.startMenu();
            switch (sel){
                case 1:
                    player = new Player(io.strReturn("Player name"));
                    updateStats(5);
                    io.playerStats(player);
                    saveFile();
                    loop = false;
                    break;
                case 2:
                    loadFile();
                    io.playerStats(player);
                    loop = false;
                    break;
            }
        }

        while (gameOn){
            startYear();
        }
    }

    public void saveFile(){
        int age = tracker.getAge();
        String playerName = player.name;
        int hp = player.getHp().value;
        int atk = player.getAtk().value;
        int mag = player.getMag().value;
        int agi = player.getAgi().value;
        int cha = player.getCha().value;

        String data = "Age=" + age +"\nPlayerName="+ playerName +"\nHP="+ hp +"\nATK="+ atk +"\nMAG="+ mag +"\nAGI="+ agi +"\nCHA="+ cha;

        file.saveFileBuff("Save.txt",data);
    }
    public void loadFile(){
        String[] out = file.readTextFileToArray("Save.txt");

        try {
            tracker.setAge(Integer.parseInt(out[0].substring(4)));
            player = new Player(out[1].substring(11),Integer.parseInt(out[2].substring(3)),
                    Integer.parseInt(out[3].substring(4)),Integer.parseInt(out[4].substring(4)),
                    Integer.parseInt(out[5].substring(4)),Integer.parseInt(out[6].substring(4)));
        } catch (Exception e){
            tracker.setAge(0);
            player = new Player(io.strReturn("Player name"));
            updateStats(5);
            io.playerStats(player);
            saveFile();
        }
    }
    public void updateStats(int howMany){
        int sel;
        while (howMany > 0){
            sel = io.StatChanger(howMany);

            switch (sel){
                case 1:
                    player.setHp(player.getHp().value + 1);
                    break;
                case 2:
                    player.setAtk(player.getAtk().value + 1);
                    break;
                case 3:
                    player.setMag(player.getMag().value + 1);
                    break;
                case 4:
                    player.setAgi(player.getAgi().value + 1);
                    break;
                case 5:
                    player.setCha(player.getCha().value + 1);
                    break;
            }
            howMany--;
        }
    }
    public void addStatsSystem(int hp, int atk, int mag, int agi, int cha){
        player.setHp(player.getHp().value + hp);
        player.setAtk(player.getAtk().value + atk);
        player.setMag(player.getMag().value + mag);
        player.setAgi(player.getAgi().value + agi);
        player.setCha(player.getCha().value + cha);
    }
    public void startYear(){
        event = tracker.eventChooser();
        eventRunner(event);
        if(player.getHp().value == 0) {
            io.display("Game Over");
            gameOn = false;
            return;
        }
        io.playerStats(player);
        updateStats(2);
        io.playerStats(player);
        tracker.ageUp();
        saveFile();
    }

    public void eventRunner(Events cur){
        cur = eventSpecial(cur); //stats and stuff
        io.showEvent(cur);
        if(cur.isBattle()){
            battle.start(cur.getEnemy(), player, tracker.timelineEnd());
            if (player.getHp().value == 0){return;}
        }
        if(cur.hasChoices()){
            int i = io.showChoice(cur.getSubEvents());
            eventRunner(cur.getSubEvents()[i-1]);
        }
    }

    public Events eventSpecial(Events cur){
        if(god && tracker.getAge()==godAge+2)
            player.setHp(0);
        switch(cur.getTitle()){
            case "Year 5":
                if(player.getAtk().value >= 5)
                    cur = tracker.randEventFind(1);
                break;
            case "Fight":
                addStatsSystem(2, 1, 0, 0, 0);
                break;
            case "Ask Father":
                addStatsSystem(0, 0, 1, 0, 0);
                break;
            case "Offer Help":
                addStatsSystem(0,0,1,0,1);
                break;
            case "Walk By", "Ignore Them":
                addStatsSystem(0,0,0,0,-1);
                break;
            case "Year 10":
                addStatsSystem(0,2,0,0,0);
                break;
            case "Step In":
                addStatsSystem(0,0,0,0,1);
                break;
            case "Drink":
                addStatsSystem((player.getHp().value*(-1))+1,-250,-250,-250,-250);
                break;
            case "Go With Him":
                addStatsSystem(0,1,3,0,1);
                break;
            case "Stay Home":
                addStatsSystem(3,3,2,1,0);
                break;
            case "Year 20":
                addStatsSystem(0,2,2,0,0);
                break;
            case "Observe Puddle":
                addStatsSystem(0,8,0,0,0);
                break;
            case "Follow the Golem":
                addStatsSystem(10,10,5,-2,0);
                break;
            case "The Random Rock":
                if (rand.nextInt(0,4) == 1){
                    cur = tracker.getBlank();
                    addStatsSystem(4,4,4,4,4);
                }
                break;
            case "Meteor", "Tsunami", "Breaking Bad", "Pressure Plate", "Mickey Mouse", "Run Away", "END":
                player.setHp(0);
                break;
            case "Heart Attack":
                player.setHp(1);
                break;
            case "Dog":
                addStatsSystem(1,0,0,0,0);
                break;
            case "Fountain of youth":
                if (rand.nextInt(0,2) == 1){
                    tracker.setAge(-1);
                } else {
                    tracker.setAge(tracker.getAge() + 4);
                }
                break;
            case "Stub Toe":
                addStatsSystem(-1,0,0,0,0);
                break;
            case "GOD":
                addStatsSystem(99,99,99,99,99);
                godAge = tracker.getAge();
                god = true;
                break;
            case "Golden Apple", "Chartreuse potion", "continue out":
                addStatsSystem(5,5,5,5,5);
                break;
            case "Accept":
                addStatsSystem(1,1,1,1,1);
                break;
            case "Reason with Ent":
                if(player.getCha().value < 7)
                    cur = new Events("Reason Failed", "Because you're not charismatic enough the Ent will not listen to you and attack you.\n",1, null,null,false);
                break;
            case "Sinkhole":
                player.setHp(player.getHp().value/2);
                player.setAgi(player.getAgi().value/2);
                break;
            case "Piano":
                player.setCha(player.getMax());
                break;
            case "Pipe bomb":
                addStatsSystem(0,-5,0,0,0);
                break;
            case "Press Enter":
                addStatsSystem(15,5,5,2,0);
                break;
            case "Prep":
                updateStats(20);
                break;
            case "People":
                addStatsSystem(-5,0,0,0,0);
                break;
            case "Touch the substance":
                addStatsSystem(+10,+5,+3,+2,0);
                break;
        }
        return cur;
    }
}